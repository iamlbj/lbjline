/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50624
Source Host           : localhost:3306
Source Database       : account

Target Server Type    : MYSQL
Target Server Version : 50624
File Encoding         : 65001

Date: 2015-05-28 18:06:23
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for dailycoast
-- ----------------------------
DROP TABLE IF EXISTS `dailycoast`;
CREATE TABLE `dailycoast` (
  `day` varchar(5) NOT NULL,
  `month` varchar(5) NOT NULL,
  `study` double NOT NULL,
  `eat` double NOT NULL,
  `shop` double NOT NULL,
  `extertainment` double NOT NULL,
  `other` double NOT NULL,
  `sum` double NOT NULL,
  PRIMARY KEY (`day`),
  KEY `month` (`month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dailycoast
-- ----------------------------
INSERT INTO `dailycoast` VALUES ('27', '05', '20', '20', '20', '20', '20', '100');
INSERT INTO `dailycoast` VALUES ('28', '05', '43', '63', '81', '25', '51', '263');

-- ----------------------------
-- Table structure for monthcoast
-- ----------------------------
DROP TABLE IF EXISTS `monthcoast`;
CREATE TABLE `monthcoast` (
  `month` varchar(5) NOT NULL,
  `study` double NOT NULL,
  `eat` double NOT NULL,
  `shop` double NOT NULL,
  `extertainment` double NOT NULL,
  `others` double NOT NULL,
  `plan` double NOT NULL,
  `actual` double NOT NULL,
  `balance` double NOT NULL,
  PRIMARY KEY (`month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of monthcoast
-- ----------------------------
INSERT INTO `monthcoast` VALUES ('05', '63', '83', '101', '45', '71', '333', '363', '-30');
