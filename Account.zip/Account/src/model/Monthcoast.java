package model;

/**
 * Monthcoast entity. @author MyEclipse Persistence Tools
 */

public class Monthcoast implements java.io.Serializable {

	// Fields

	private String month;
	private Double study;
	private Double eat;
	private Double shop;
	private Double extertainment;
	private Double others;
	private Double plan;
	private Double actual;
	private Double balance;

	// Constructors

	/** default constructor */
	public Monthcoast() {
	}

	/** full constructor */
	public Monthcoast(String month, Double study, Double eat, Double shop,
			Double extertainment, Double others, Double plan, Double actual,
			Double balance) {
		this.month = month;
		this.study = study;
		this.eat = eat;
		this.shop = shop;
		this.extertainment = extertainment;
		this.others = others;
		this.plan = plan;
		this.actual = actual;
		this.balance = balance;
	}

	// Property accessors

	public String getMonth() {
		return this.month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public Double getStudy() {
		return this.study;
	}

	public void setStudy(Double study) {
		this.study = study;
	}

	public Double getEat() {
		return this.eat;
	}

	public void setEat(Double eat) {
		this.eat = eat;
	}

	public Double getShop() {
		return this.shop;
	}

	public void setShop(Double shop) {
		this.shop = shop;
	}

	public Double getExtertainment() {
		return this.extertainment;
	}

	public void setExtertainment(Double extertainment) {
		this.extertainment = extertainment;
	}

	public Double getOthers() {
		return this.others;
	}

	public void setOthers(Double others) {
		this.others = others;
	}

	public Double getPlan() {
		return this.plan;
	}

	public void setPlan(Double plan) {
		this.plan = plan;
	}

	public Double getActual() {
		return this.actual;
	}

	public void setActual(Double actual) {
		this.actual = actual;
	}

	public Double getBalance() {
		return this.balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

}