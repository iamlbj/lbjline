package model;

/**
 * Dailycoast entity. @author MyEclipse Persistence Tools
 */

public class Dailycoast implements java.io.Serializable {

	// Fields

	private String day;
	private String month;
	private Double study;
	private Double eat;
	private Double shop;
	private Double extertainment;
	private Double other;
	private Double sum;

	// Constructors

	/** default constructor */
	public Dailycoast() {
	}

	/** full constructor */
	public Dailycoast(String day, String month, Double study, Double eat,
			Double shop, Double extertainment, Double other, Double sum) {
		this.day = day;
		this.month = month;
		this.study = study;
		this.eat = eat;
		this.shop = shop;
		this.extertainment = extertainment;
		this.other = other;
		this.sum = sum;
	}

	// Property accessors

	public String getDay() {
		return this.day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getMonth() {
		return this.month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public Double getStudy() {
		return this.study;
	}

	public void setStudy(Double study) {
		this.study = study;
	}

	public Double getEat() {
		return this.eat;
	}

	public void setEat(Double eat) {
		this.eat = eat;
	}

	public Double getShop() {
		return this.shop;
	}

	public void setShop(Double shop) {
		this.shop = shop;
	}

	public Double getExtertainment() {
		return this.extertainment;
	}

	public void setExtertainment(Double extertainment) {
		this.extertainment = extertainment;
	}

	public Double getOther() {
		return this.other;
	}

	public void setOther(Double other) {
		this.other = other;
	}

	public Double getSum() {
		return this.sum;
	}

	public void setSum(Double sum) {
		this.sum = sum;
	}

}