package Class;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.Transaction;
import factory.HibernateSessionFactory;

import model.Monthcoast;
import dao.MonthcoastDAO;

public class LoginClass {

    private MonthcoastDAO monthCoastDAO;
    private Monthcoast monthcoast;

    //�Ҳ���������Ϣ����û�мƻ���֧�����ʧ��    
    public int planCheck(){
    	SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//�������ڸ�ʽ
    	String date = df.format(new Date());// new Date()Ϊ��ȡ��ǰϵͳʱ��	
    	String strArray[] = date.split("-");
    	monthcoast = new Monthcoast();
    	monthCoastDAO = new MonthcoastDAO();
    	
    	monthcoast = monthCoastDAO.findById(strArray[1]);
    	if(monthcoast == null||monthcoast.getPlan()==0.0){
    		return 0;
    	}
		return 1;
    }
    
    //���¿�֧��ʼ�������ҵõ��ƻ���֧
    public void initPlan(String planCoast){
    	SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//�������ڸ�ʽ
    	String date = df.format(new Date());// new Date()Ϊ��ȡ��ǰϵͳʱ��	
    	String strArray[] = date.split("-");
    	
    	monthcoast = new Monthcoast();
    	monthcoast.setMonth(strArray[1]);
    	monthcoast.setActual(0.0);
    	monthcoast.setBalance(0.0);
    	monthcoast.setEat(0.0);
    	monthcoast.setExtertainment(0.0);
    	monthcoast.setShop(0.0);
    	monthcoast.setStudy(0.0);
    	monthcoast.setOthers(0.0);
    	monthcoast.setPlan(Double.valueOf(planCoast));
    	
    	Session session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		
		session.clear();
		try{
			session.merge(monthcoast);
		}
		catch(Exception e1){
		}
		tx.commit();
		session.close();
    	
    }
}
