package Class;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import dao.DailycoastDAO;
import factory.HibernateSessionFactory;
import model.Dailycoast;

public class DailyRecordClass {
	
	private DailycoastDAO dailydao;
	private Dailycoast dailycoast;
	
    //��ʼ�����յ��˵�
	public Dailycoast initDailyRecord(){
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//�������ڸ�ʽ
    	String date = df.format(new Date());// new Date()Ϊ��ȡ��ǰϵͳʱ��	
    	String strArray[] = date.split("-");
    	dailydao = new DailycoastDAO();
    	
    	dailycoast = new Dailycoast();
    	dailycoast = dailydao.findById(strArray[2]);
    	if(dailycoast==null){
    		dailycoast = new Dailycoast();
    	    dailycoast.setDay(strArray[2]);
    	    dailycoast.setEat(0.0);
    	    dailycoast.setExtertainment(0.0);
    	    dailycoast.setMonth(strArray[1]);
    	    dailycoast.setOther(0.0);
    	    dailycoast.setShop(0.0);
    	    dailycoast.setStudy(0.0);
    	    dailycoast.setSum(0.0);
    	}
    	return dailycoast;
	}
	
	//�������Ѽ������ݿ�
	public void dailyRecord(Dailycoast temp){
		dailycoast = new Dailycoast();
		dailycoast = initDailyRecord();
	    dailycoast.setEat((dailycoast.getEat()+temp.getEat()));
	    dailycoast.setExtertainment((dailycoast.getExtertainment()+temp.getExtertainment()));
	    dailycoast.setOther((dailycoast.getOther()+temp.getOther()));
	    dailycoast.setShop((dailycoast.getShop()+temp.getShop()));
	    dailycoast.setStudy((dailycoast.getStudy()+temp.getStudy()));
	    dailycoast.setSum(dailycoast.getEat()+dailycoast.getExtertainment()+dailycoast.getOther()+dailycoast.getShop()+dailycoast.getStudy());
	    
	    Session session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		
		session.clear();
		try{
			session.merge(dailycoast);
		}
		catch(Exception e1){
		}
		tx.commit();
		session.close();
	}
	
	//�õ�ĳ��������Ŀ
	public List getRecordByMonth(String month){
		List ls;
		dailydao = new DailycoastDAO();
		ls = dailydao.findByMonth(month);
		return ls;
	}
	
	//�õ�ĳ�յļ�¼
	public Dailycoast getRecordByDay(String day){
		dailycoast = new Dailycoast();
		dailydao = new DailycoastDAO();
		dailycoast = dailydao.findById(day);
		return dailycoast;
	}
	
}
