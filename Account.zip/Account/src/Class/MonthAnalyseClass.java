package Class;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import model.Dailycoast;
import model.Monthcoast;
import dao.DailycoastDAO;
import dao.MonthcoastDAO;
import factory.HibernateSessionFactory;

public class MonthAnalyseClass {
	private DailycoastDAO dailydao;
	private MonthcoastDAO monthdao;
	
	//�������ͳ�����ݵ��·�
	public List findAllMonth(){
		List ls;
		monthdao = new MonthcoastDAO();
		ls = monthdao.findAll();
		return ls;
	}
	
    //��ѯ��ĳ�µļ�¼
	public Monthcoast searchMonthData(String month){
		Monthcoast temp = new Monthcoast();
		temp = monthdao.findById(month);
		return temp;
	}
	
	//ÿ������ͳ��
	public void monthAnalyse(){
		Monthcoast monthcoast = new Monthcoast();
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//�������ڸ�ʽ
    	String date = df.format(new Date());// new Date()Ϊ��ȡ��ǰϵͳʱ��	
    	String strArray[] = date.split("-");
    	String month = strArray[1];
    	
    	monthdao = new MonthcoastDAO();
    	monthcoast = monthdao.findById(month);
    	monthcoast.setActual(0.0);
    	monthcoast.setBalance(0.0);
    	monthcoast.setEat(0.0);
    	monthcoast.setExtertainment(0.0);
    	monthcoast.setShop(0.0);
    	monthcoast.setStudy(0.0);
    	monthcoast.setOthers(0.0);
    	
		List ls;
		dailydao = new DailycoastDAO();
		ls = dailydao.findAll();
		
		for(int i=0;i<ls.size();i++){
			monthcoast.setEat(monthcoast.getEat()+((Dailycoast)(ls.get(i))).getEat());
			monthcoast.setExtertainment(monthcoast.getExtertainment()+((Dailycoast)(ls.get(i))).getExtertainment());
			monthcoast.setOthers(monthcoast.getOthers()+((Dailycoast)(ls.get(i))).getOther());
			monthcoast.setShop(monthcoast.getShop()+((Dailycoast)(ls.get(i))).getShop());
			monthcoast.setStudy(monthcoast.getStudy()+((Dailycoast)(ls.get(i))).getStudy());
			monthcoast.setActual(monthcoast.getActual()+((Dailycoast)(ls.get(i))).getSum());
			monthcoast.setBalance(monthcoast.getPlan()-monthcoast.getActual());
		} 
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		
		session.clear();
		try{
			session.merge(monthcoast);
		}
		catch(Exception e1){
		}
		tx.commit();
		session.close();
	}
}
