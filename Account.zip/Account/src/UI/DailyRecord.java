package UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JFormattedTextField;
import javax.swing.JButton;

import model.Dailycoast;
import Class.DailyRecordClass;
import Class.LoginClass;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class DailyRecord extends JFrame {

	static DailyRecord frame = new DailyRecord();
	private LoginClass login;
	private JPanel contentPane;
	private JTextField studyCoast;
	private JTextField eatCoast;
	private JTextField entertainCoast;
	private JTextField shopCoast;
	private JTextField otherCoast;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DailyRecord() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 312, 509);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel study = new JLabel("\u5B66\u4E60\u5F00\u652F");
		study.setFont(new Font("΢���ź�", Font.BOLD, 16));
		study.setBounds(46, 33, 86, 32);
		contentPane.add(study);
		
		JLabel eat = new JLabel("\u996E\u98DF\u5F00\u652F");
		eat.setFont(new Font("΢���ź�", Font.BOLD, 16));
		eat.setBounds(46, 111, 72, 18);
		contentPane.add(eat);
		
		JLabel entertainment = new JLabel("\u5A31\u4E50\u5F00\u652F");
		entertainment.setFont(new Font("΢���ź�", Font.BOLD, 16));
		entertainment.setBounds(46, 176, 72, 18);
		contentPane.add(entertainment);
		
		JLabel shop = new JLabel("\u8D2D\u7269\u5F00\u652F");
		shop.setFont(new Font("΢���ź�", Font.BOLD, 16));
		shop.setBounds(46, 243, 72, 18);
		contentPane.add(shop);
		
		JLabel others = new JLabel("\u5176\u4ED6\u5F00\u652F");
		others.setFont(new Font("΢���ź�", Font.BOLD, 16));
		others.setBounds(46, 312, 72, 18);
		contentPane.add(others);
		
		studyCoast = new JTextField();
		studyCoast.setBounds(159, 38, 86, 24);
		contentPane.add(studyCoast);
		studyCoast.setColumns(10);
		studyCoast.addKeyListener(new KeyListener() {  
		    @Override  
		    public void keyTyped(KeyEvent e) {  
		        // ֻ����������  
		        char keyCh = e.getKeyChar();  
		        if ((keyCh < '0') || (keyCh > '9')) {  
		            if (keyCh != '\n') // �س��ַ�  
		                e.setKeyChar('\0');  
		        }  
		    }  
		  
		    @Override  
		    public void keyReleased(KeyEvent e) {  
		    }  
		  
		    @Override  
		    public void keyPressed(KeyEvent e) {  
		    }  
		});  
		
		eatCoast = new JTextField();
		eatCoast.setBounds(159, 109, 86, 24);
		contentPane.add(eatCoast);
		eatCoast.setColumns(10);
		eatCoast.addKeyListener(new KeyListener() {  
		    @Override  
		    public void keyTyped(KeyEvent e) {  
		        // ֻ����������  
		        char keyCh = e.getKeyChar();  
		        if ((keyCh < '0') || (keyCh > '9')) {  
		            if (keyCh != '\n') // �س��ַ�  
		                e.setKeyChar('\0');  
		        }  
		    }  
		  
		    @Override  
		    public void keyReleased(KeyEvent e) {  
		    }  
		  
		    @Override  
		    public void keyPressed(KeyEvent e) {  
		    }  
		});  
		
		entertainCoast = new JTextField();
		entertainCoast.setBounds(159, 174, 86, 24);
		contentPane.add(entertainCoast);
		entertainCoast.setColumns(10);
		entertainCoast.addKeyListener(new KeyListener() {  
		    @Override  
		    public void keyTyped(KeyEvent e) {  
		        // ֻ����������  
		        char keyCh = e.getKeyChar();  
		        if ((keyCh < '0') || (keyCh > '9')) {  
		            if (keyCh != '\n') // �س��ַ�  
		                e.setKeyChar('\0');  
		        }  
		    }  
		  
		    @Override  
		    public void keyReleased(KeyEvent e) {  
		    }  
		  
		    @Override  
		    public void keyPressed(KeyEvent e) {  
		    }  
		});  
		
		shopCoast = new JTextField();
		shopCoast.setBounds(159, 241, 86, 24);
		contentPane.add(shopCoast);
		shopCoast.setColumns(10);
		shopCoast.addKeyListener(new KeyListener() {  
		    @Override  
		    public void keyTyped(KeyEvent e) {  
		        // ֻ����������  
		        char keyCh = e.getKeyChar();  
		        if ((keyCh < '0') || (keyCh > '9')) {  
		            if (keyCh != '\n') // �س��ַ�  
		                e.setKeyChar('\0');  
		        }  
		    }  
		  
		    @Override  
		    public void keyReleased(KeyEvent e) {  
		    }  
		  
		    @Override  
		    public void keyPressed(KeyEvent e) {  
		    }  
		});  
		
		otherCoast = new JTextField();
		otherCoast.setBounds(159, 312, 86, 24);
		contentPane.add(otherCoast);
		otherCoast.setColumns(10);
		otherCoast.addKeyListener(new KeyListener() {  
		    @Override  
		    public void keyTyped(KeyEvent e) {  
		        // ֻ����������  
		        char keyCh = e.getKeyChar();  
		        if ((keyCh < '0') || (keyCh > '9')) {  
		            if (keyCh != '\n') // �س��ַ�  
		                e.setKeyChar('\0');  
		        }  
		    }  
		  
		    @Override  
		    public void keyReleased(KeyEvent e) {  
		    }  
		  
		    @Override  
		    public void keyPressed(KeyEvent e) {  
		    }  
		});  
		
		JButton record = new JButton("\u8BB0\u5F55");
		record.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Dailycoast temp = new Dailycoast();
				
				if(eatCoast.getText().toString().equals("")){
					temp.setEat(0.0);
				}else{
				    temp.setEat(Double.valueOf(eatCoast.getText().toString()));
				}
				
				if(entertainCoast.getText().toString().equals("")){
				    temp.setExtertainment(0.0);
				}else{
					temp.setExtertainment(Double.valueOf(entertainCoast.getText().toString()));
				}
				
				if(shopCoast.getText().toString().equals("")){
					temp.setShop(0.0);
				}else{
				    temp.setShop(Double.valueOf(shopCoast.getText().toString()));
				}
				
				if(otherCoast.getText().toString().equals("")){
					temp.setOther(0.0);
				}else{
				    temp.setOther(Double.valueOf(otherCoast.getText().toString()));
				}
				
				if(studyCoast.getText().toString().equals("")){
					temp.setStudy(0.0);
				}else{
				    temp.setStudy(Double.valueOf(studyCoast.getText().toString()));
				}
				
				DailyRecordClass record = new DailyRecordClass();
				record.dailyRecord(temp);
				
			    JOptionPane.showMessageDialog(null, "��¼�ɹ�","", JOptionPane.WARNING_MESSAGE);
				updateUI();
			}
		});
		record.setFont(new Font("΢���ź�", Font.BOLD, 16));
		record.setBounds(159, 364, 86, 27);
		contentPane.add(record);
		
		JButton search = new JButton("\u67E5\u8BE2");
		search.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateUI();
				frame.dispose();
				Search.frame.show();
			}
		});
		search.setFont(new Font("΢���ź�", Font.BOLD, 16));
		search.setBounds(46, 410, 72, 27);
		contentPane.add(search);
		
		JButton concern = new JButton("\u9000\u51FA");
		concern.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				updateUI();
				System.exit(0);
			}
		});
		concern.setFont(new Font("΢���ź�", Font.BOLD, 16));
		concern.setBounds(159, 410, 86, 27);
		contentPane.add(concern);
	}
	
	public void updateUI(){
		eatCoast.setText("");
		shopCoast.setText("");
		entertainCoast.setText("");
		otherCoast.setText("");
		studyCoast.setText("");
	}
}
