package UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JTextField;
import javax.swing.JButton;

import Class.LoginClass;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Login extends JFrame {

	static Login frame = new Login();
	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginClass login = new LoginClass();
		            int check = login.planCheck();
		            if(check==0){
		            	frame.setVisible(true);
		            }else{
		          	    DailyRecord.frame.show();
		            }	
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 405, 295);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel text = new JLabel("\u8BF7\u8F93\u5165\u672C\u6708\u8BA1\u5212\u5F00\u652F\uFF1A");
		text.setFont(new Font("΢���ź�", Font.BOLD, 16));
		text.setBounds(36, 84, 160, 37);
		contentPane.add(text);
		
		textField = new JTextField();
		textField.setBounds(238, 88, 105, 30);
		contentPane.add(textField);
		textField.setColumns(10);
		textField.addKeyListener(new KeyListener() {  
		    @Override  
		    public void keyTyped(KeyEvent e) {  
		        // ֻ����������  
		        char keyCh = e.getKeyChar();  
		        if ((keyCh < '0') || (keyCh > '9')) {  
		            if (keyCh != '\n') // �س��ַ�  
		                e.setKeyChar('\0');  
		        }  
		    }  
		  
		    @Override  
		    public void keyReleased(KeyEvent e) {  
		    }  
		  
		    @Override  
		    public void keyPressed(KeyEvent e) {  
		    }  
		});  

		
		JButton confirmButton = new JButton("\u786E\u8BA4");
		confirmButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				LoginClass login = new LoginClass();
				login.initPlan(textField.getText().toString());
				textField.setText("");
				DailyRecord.frame.show();
			    frame.dispose();
			}
		});
		confirmButton.setFont(new Font("΢���ź�", Font.BOLD, 16));
		confirmButton.setBounds(122, 185, 113, 27);
		contentPane.add(confirmButton);
	}
}
