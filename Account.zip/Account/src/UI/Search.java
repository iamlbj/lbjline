package UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Vector;

import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import dao.DailycoastDAO;
import model.Dailycoast;
import model.Monthcoast;
import Class.DailyRecordClass;
import Class.MonthAnalyseClass;

import javax.swing.JButton;

public class Search extends JFrame {

	static Search frame = new Search();
	private JPanel contentPane;
	private JTable monthTable;
	private JTable dayTable;
	private JTable ItemTable;
	private JComboBox month;
	private JComboBox day;
	private DefaultTableModel dtm;
	private DefaultTableModel dtm2;
	private DefaultTableModel dtm3;
	
	private Monthcoast monthcoast;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Search() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 684, 491);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel monthChose = new JLabel("\u8BF7\u9009\u62E9\u6708\u4EFD\uFF1A");
		monthChose.setFont(new Font("΢���ź�", Font.BOLD, 16));
		monthChose.setBounds(47, 43, 104, 18);
		contentPane.add(monthChose);
		
		JLabel dateChose = new JLabel("\u8BF7\u9009\u62E9\u65E5\u671F\uFF1A");
		dateChose.setFont(new Font("΢���ź�", Font.BOLD, 16));
		dateChose.setBounds(47, 90, 104, 18);
		contentPane.add(dateChose);
		
		month = new JComboBox();
		List monthls = new MonthAnalyseClass().findAllMonth();
	    for(int i=0;i<monthls.size();i++){
			month.addItem(((Monthcoast)(monthls).get(i)).getMonth());
	    }
		month.setBounds(298, 41, 78, 24);
		contentPane.add(month);
		
		day = new JComboBox();
		List dayls = new DailyRecordClass().getRecordByMonth(month.getSelectedItem().toString());
    	for(int i=0;i<dayls.size();i++){
	        day.addItem(((Dailycoast)(dayls).get(i)).getDay());
        }
		final ActionListener actionListener = new ActionListener() {  
		    public void actionPerformed(ActionEvent actionEvent) {
		    	day.removeAllItems();
		        List dayls = new DailyRecordClass().getRecordByMonth(month.getSelectedItem().toString());
	        	for(int i=0;i<dayls.size();i++){
			        day.addItem(((Dailycoast)(dayls).get(i)).getDay());
		        }
	        	if(month.getSelectedItem()!=null){
	        	    ItemTableInit();
	        	    monthTableInit();
	        	}
	        	if(day.getSelectedItem()!=null){
		        	dtm2.setNumRows(0);
		    	    dayTableInit();
		        }
		    }
		};
	    month.addActionListener(actionListener);
		
		day.setBounds(298, 88, 78, 24);
		final ActionListener actionListener1 = new ActionListener() {  
		    public void actionPerformed(ActionEvent actionEvent) {
		        if(day.getSelectedItem()!=null){
		        	dtm2.setNumRows(0);
		    	    dayTableInit();
		        }
		    }
		};
		day.addActionListener(actionListener1);
		contentPane.add(day);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(47, 170, 329, 75);
		contentPane.add(scrollPane);
		
		monthTable = new JTable();
		String[] colname = {"�·�","�ƻ���֧","ʵ�ʿ�֧","����"};
		dtm = new DefaultTableModel();
  	    dtm = (DefaultTableModel)monthTable.getModel();
  	    dtm.setColumnIdentifiers(colname);
		scrollPane.setViewportView(monthTable);
		
		JLabel text1 = new JLabel("\u6708\u5F00\u652F\u603B\u8BA1\uFF1A");
		text1.setFont(new Font("΢���ź�", Font.BOLD, 16));
		text1.setBounds(47, 139, 104, 18);
		contentPane.add(text1);
		
		JLabel text2 = new JLabel("\u65E5\u5F00\u652F\u7EDF\u8BA1\uFF1A");
		text2.setFont(new Font("΢���ź�", Font.BOLD, 16));
		text2.setBounds(47, 275, 104, 18);
		contentPane.add(text2);
		
		JLabel text3 = new JLabel("\u6761\u76EE\u7EDF\u8BA1\uFF1A");
		text3.setFont(new Font("΢���ź�", Font.BOLD, 16));
		text3.setBounds(421, 44, 86, 18);
		contentPane.add(text3);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(47, 317, 329, 40);
		contentPane.add(scrollPane_1);
		
		dayTable = new JTable();
		String[] colname1 = {"����","ѧϰ��֧","��ʳ��֧","���ֿ�֧","���￪֧","������֧"};
		dtm2 = new DefaultTableModel();
  	    dtm2 = (DefaultTableModel)dayTable.getModel();
  	    dtm2.setColumnIdentifiers(colname1);
		scrollPane_1.setViewportView(dayTable);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(421, 90, 222, 267);
		contentPane.add(scrollPane_2);
		
		ItemTable = new JTable();
		String[] colname2 = {"��֧��Ŀ","��֧���","��ռ����"};
		dtm3 = new DefaultTableModel();
  	    dtm3= (DefaultTableModel)ItemTable.getModel();
  	    dtm3.setColumnIdentifiers(colname2);
		scrollPane_2.setViewportView(ItemTable);
		
		JButton returnButton = new JButton("\u8FD4\u56DE");
		returnButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateUI();
				frame.dispose();
				DailyRecord.frame.show();
			}
		});
		returnButton.setFont(new Font("΢���ź�", Font.BOLD, 16));
		returnButton.setBounds(421, 388, 86, 27);
		contentPane.add(returnButton);
		
		JButton concern = new JButton("\u9000\u51FA");
		concern.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		concern.setFont(new Font("΢���ź�", Font.BOLD, 16));
		concern.setBounds(557, 389, 86, 27);
		contentPane.add(concern);
	}
	
	public void monthTableInit(){
		dtm.setRowCount(0);
		monthcoast = new Monthcoast();
		MonthAnalyseClass monthanalyse = new MonthAnalyseClass();
		monthanalyse.monthAnalyse();
		monthcoast = monthanalyse.searchMonthData(month.getSelectedItem().toString());
		Vector vector;
		vector = new Vector();
		vector.add(monthcoast.getMonth());
		vector.add(monthcoast.getPlan());
		vector.add(monthcoast.getActual());
		vector.add(monthcoast.getBalance());
		dtm.addRow(vector);
	}
	
	public void dayTableInit(){
		dtm2.setRowCount(0);
		Dailycoast dailycoast = new Dailycoast();
		DailyRecordClass dailyclass = new DailyRecordClass();
		dailycoast = dailyclass.getRecordByDay(day.getSelectedItem().toString());
		Vector vector;
		vector = new Vector();
		vector.add(dailycoast.getDay());
		vector.add(dailycoast.getStudy());
		vector.add(dailycoast.getEat());
		vector.add(dailycoast.getExtertainment());
		vector.add(dailycoast.getShop());
		vector.add(dailycoast.getOther());
		dtm2.addRow(vector);
	}
	
	public void ItemTableInit(){
		dtm3.setRowCount(0);
		monthcoast = new Monthcoast();
		MonthAnalyseClass monthanalyse = new MonthAnalyseClass();
		monthanalyse.monthAnalyse();
		monthcoast = monthanalyse.searchMonthData(month.getSelectedItem().toString());
		DecimalFormat df = new DecimalFormat(".00");
		Vector vector;
		vector = new Vector();
		
		vector.add("ѧϰ֧��");
		vector.add(monthcoast.getStudy());
		vector.add(df.format(monthcoast.getStudy()/monthcoast.getActual()*100)+"%");
		dtm3.addRow(vector);
		
		vector = new Vector();
		vector.add("��ʳ֧��");
		vector.add(monthcoast.getEat());
		vector.add(df.format(monthcoast.getEat()/monthcoast.getActual()*100)+"%");
		dtm3.addRow(vector);
		
		vector = new Vector();
		vector.add("����֧��");
		vector.add(monthcoast.getShop());
		vector.add(df.format(monthcoast.getShop()/monthcoast.getActual()*100)+"%");
		dtm3.addRow(vector);
		
		vector = new Vector();
		vector.add("����֧��");
		vector.add(monthcoast.getExtertainment());
		vector.add(df.format(monthcoast.getExtertainment()/monthcoast.getActual()*100)+"%");
		dtm3.addRow(vector);
		
		vector = new Vector();
		vector.add("����֧��");
		vector.add(monthcoast.getOthers());
		vector.add(df.format(monthcoast.getOthers()/monthcoast.getActual()*100)+"%");
		dtm3.addRow(vector);
	}
	
	public void updateUI(){
		dtm.setRowCount(0);
		dtm2.setRowCount(0);
		dtm3.setRowCount(0);
	}
}
